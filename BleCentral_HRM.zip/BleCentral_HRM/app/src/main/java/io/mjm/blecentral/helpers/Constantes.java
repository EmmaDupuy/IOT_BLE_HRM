package io.mjm.blecentral.helpers;

public class Constantes {
    public static final int REQUEST_ENABLE_BT=1;
}
